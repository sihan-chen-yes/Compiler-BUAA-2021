package Optimizer;

public class EndBlock extends BasicBlock {

    @Override
    public String toString() {
        return "";
    }
}
