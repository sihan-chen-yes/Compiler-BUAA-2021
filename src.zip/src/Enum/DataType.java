package Enum;
public enum DataType {
    INT,
    VOID,
    INT_ARRAY_1D,
    INT_ARRAY_2D,
    UNDEFINED,
}
