package Enum;

public enum CalType {
    add, sub,
    not,
    mul,div,mod,
    lt,gt,le,ge,
    eq,neq
}
