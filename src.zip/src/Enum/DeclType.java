package Enum;

public enum DeclType {
    VAR,
    CONST,
    FUNC,
    PARAM,
    TEMP,
}
