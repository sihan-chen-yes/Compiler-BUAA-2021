public class SymbolTableEntry {
}
