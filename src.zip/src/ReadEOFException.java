public class ReadEOFException extends Exception{

}
