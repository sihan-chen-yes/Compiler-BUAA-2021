package ASTNode;

public class EmptyStmt extends Node {
    public EmptyStmt(int pos) {
        super(pos);
    }
}
