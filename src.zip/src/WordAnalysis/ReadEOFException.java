package WordAnalysis;

public class ReadEOFException extends Exception {

}
